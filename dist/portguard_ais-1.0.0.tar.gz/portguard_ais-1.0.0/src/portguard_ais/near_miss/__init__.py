"""Historical near-miss mining."""
